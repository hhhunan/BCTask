<?php
return [
    'successfully_created'=>'You are successfully created visit.',
    'successfully_deleted'=>'You are successfully deleted the visit.',
    'something_error'=>'Something won`t the wrong, please try later!',
    'visitor_not_found'=>'Visitor not found.',
];
