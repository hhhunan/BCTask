<?php
return [
  'types' =>[
      'guest'=>'Guest',
      'press'=>'Press',
      'speaker'=>'Speaker',
  ],
];
