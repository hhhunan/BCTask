<?php
return [
    'successfully_created'=>'Вы успешно создали визит.',
    'something_error'=>'Что-то не так, попробуйте позже!',
    'successfully_deleted'=>'Вы успешно удалили визит.',
    'visitor_not_found'=>'Посетитель не найден.',
];
