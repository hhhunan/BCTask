<?php
return [
  'types' =>[
      'guest'=>'Гость',
      'press'=>'Пресса',
      'speaker'=>'Докладчик',
  ],
];
