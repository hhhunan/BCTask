<?php

namespace App\Exceptions;

use Exception;

class BusinessLogicException extends Exception
{
    //
}
